const t=document.getElementById("password_toggle"),e=document.getElementById("password");t.addEventListener("change",s=>{e.type=e.type=="password"?"text":"password"});
